package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DockerProject {
	@GetMapping("/get")
	public String show1()
	{
		return "Docker-Docker is an open platform for developing, shipping, and running applications.";
	}
	@GetMapping("/in")
	public String show2()
	{
		return "This is a Docker Project which show how to dockerize a simple spring boot project.";
	}

}
