package com.amdocs.project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver; import org.openqa.selenium.edge.EdgeDriver; import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
public class TestJava {
WebDriver dr= new EdgeDriver(); SoftAssert sa=new SoftAssert();
 @Test
public void titletestpass() {
           dr.get("https://www.khadinatural.com/");
           String expTitile = "KhadiNaturals";
           String actTitle = dr.getTitle();
           //System.out.println(actTitle);

 System.out.println(dr.getTitle()); sa.assertEquals(actTitle, expTitile);
//String btnText=dr.findElement(By.xpath("//*[@id=\"RA- root\"]/div/div[1]/div[1]/div[2]/span/span/span[2]/button")).getText ();
//System.out.println(btnText); String expText="Search"; sa.assertEquals(btnText, expText); sa.assertAll();
}
}