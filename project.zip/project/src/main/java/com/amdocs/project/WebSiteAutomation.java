package com.amdocs.project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class WebSiteAutomation {
	public static WebDriver dr;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//load the driver
		 dr=new EdgeDriver();
		 
		 //load the website
		dr.get("https://www.khadinatural.com/");
		//maximize the window
		dr.manage().window().maximize();
		
		//Thread.sleep()-refers to the wait of action for the specified time
		Thread.sleep(4000);
		
		//login into the account
		WebElement login=dr.findElement(By.xpath("//*[@id=\"shopify-section-sections--20758378807618__header\"]/height-observer/x-header/nav[2]/a[1]"));
		login.click();
		Thread.sleep(5000);
		WebElement mail=dr.findElement(By.xpath("//*[@id=\"input-template--20758378119490__main--customeremail\"]"));
		mail.sendKeys("dandekarswarali0721@gmail.com");
		WebElement pass=dr.findElement(By.xpath("//*[@id=\"input-template--20758378119490__main--customerpassword\"]"));
		pass.sendKeys("Khadinatural@07");
		dr.findElement(By.xpath("//*[@id=\"customer_login\"]/button")).click();
		Thread.sleep(3000);
		
		//navigation to skincare and adding product to cart
		dr.navigate().to("https://www.khadinatural.com/collections/skin-care");
		dr.findElement(By.xpath("//*[@id=\"shopify-section-template--20758376841538__main\"]/div/div/height-observer/div/div[1]/button")).click();
		dr.findElement(By.xpath("//*[@id=\"product_form_6722639953971\"]/button")).click();
		Thread.sleep(3000);
		
		//navigating to gifts/combos and adding product to cart
		dr.navigate().to("https://www.khadinatural.com/collections/gifts-kits-combos");
		dr.findElement(By.cssSelector("#product_form_6722591260723 > button")).click();
		Thread.sleep(3000);
		
		//payment checkout
		dr.findElement(By.xpath("//*[@id=\"cart-drawer\"]/form/div[2]/button[2]")).click();
		Thread.sleep(3000);
		
		//procedure to add address for shipping-(once added it gets saved no need to add again)
		
//		dr.findElement(By.xpath("//*[@id=\"shipping-address1\"]")).sendKeys("Panvel");
//		dr.findElement(By.xpath("//*[@id=\"TextField3\"]")).sendKeys("Navi Mumbai");
//	    Select s=new Select(dr.findElement(By.xpath("//*[@id=\"Select1\"]")));
//		s.selectByVisibleText("Maharashtra");
//		dr.findElement(By.xpath("//*[@id=\"TextField4\"]")).sendKeys("410206");
//		dr.findElement(By.xpath("//*[@id=\"TextField5\"]")).sendKeys("9845123652");
		//dr.findElement(By.xpath("//*[@id=\"pay-button-container\"]/div/div/button")).click();
	}
	
	
		
		

}
